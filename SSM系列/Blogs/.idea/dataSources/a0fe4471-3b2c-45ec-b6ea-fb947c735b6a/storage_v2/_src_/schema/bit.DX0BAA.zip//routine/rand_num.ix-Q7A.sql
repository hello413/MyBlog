create
    definer = root@localhost function rand_num(n int) returns int(5)
begin
 declare i int default 0;
set i = floor(rand()*n);
return i;
end;

